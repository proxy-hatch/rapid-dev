"""Deterministic model stub. Real harness/runtime, no live model inference."""
import json, time, uuid, re
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
ROOT = Path(__file__).parent
class Handler(BaseHTTPRequestHandler):
    def log_message(self, *args): pass
    def do_GET(self):
        result={'data':[{'id':'trial','object':'model'}],'object':'list'}
        self.send_response(200); self.send_header('Content-Type','application/json'); self.end_headers(); self.wfile.write(json.dumps(result).encode())
    def do_POST(self):
        data=json.loads(self.rfile.read(int(self.headers.get('Content-Length',0))))
        # Request bodies contain only synthetic trial prompts; headers are never logged.
        with (ROOT/'model-requests.jsonl').open('a') as f: f.write(json.dumps({'at':time.time(),'path':self.path,'body':data})+'\n')
        messages=data.get('messages', data.get('input',[]))
        if isinstance(messages,str): messages=[{'role':'user','content':messages}]
        last_user=-1; op=None
        for i,m in enumerate(messages):
            content=m.get('content','')
            text=content if isinstance(content,str) else '\n'.join(x.get('text','') for x in content if isinstance(x,dict))
            if m.get('role')=='user' and 'TRIAL_OP=' in text:
                last_user=i
                try: op=json.JSONDecoder().raw_decode(text.split('TRIAL_OP=',1)[1])[0]
                except ValueError: pass
        completed=any(m.get('role')=='tool' or m.get('type')=='function_call_output' for m in messages[last_user+1:])
        tools=data.get('tools',[]); function=None
        if op and not completed:
            names=[t.get('function',t).get('name') for t in tools]
            function=next((n for n in names if n in ['exec_command','shell_command','shell']),None)
            if function:
                command=op.get('command','printf trial-ok')
                args={'cmd':command,'yield_time_ms':1000,'max_output_tokens':1000} if function=='exec_command' else {'command':command} if function=='shell_command' else {'command':['bash','-lc',command]}
        if completed:
            outputs=[m for m in messages[last_user+1:] if m.get('role')=='tool' or m.get('type')=='function_call_output']
            latest=json.dumps(outputs[-1]) if outputs else ''
            session=re.search(r'(?:Process running with session ID\s+|session_id[\\" :]+)([0-9]+)',latest)
            names=[t.get('function',t).get('name') for t in tools]
            if session and 'write_stdin' in names:
                function='write_stdin'; args={'session_id':int(session.group(1)),'chars':'','yield_time_ms':1000,'max_output_tokens':1000}
        call_id='call_'+uuid.uuid4().hex[:12]
        message={'role':'assistant','content':'TRIAL_DONE'}
        if function: message={'role':'assistant','content':None,'tool_calls':[{'id':call_id,'type':'function','function':{'name':function,'arguments':json.dumps(args)}}]}
        response_id='resp_'+uuid.uuid4().hex
        self.send_response(200)
        if data.get('stream'):
            self.send_header('Content-Type','text/event-stream'); self.end_headers()
            def send(value,event=None):
                if event: self.wfile.write(('event: '+event+'\n').encode())
                self.wfile.write(('data: '+json.dumps(value)+'\n\n').encode()); self.wfile.flush()
            if '/responses' in self.path:
                item={'type':'function_call','id':'fc_'+call_id,'call_id':call_id,'name':function,'arguments':json.dumps(args),'status':'completed'} if function else {'id':'msg_'+call_id,'type':'message','role':'assistant','status':'completed','content':[{'type':'output_text','text':'TRIAL_DONE','annotations':[]}]}
                response={'id':response_id,'object':'response','status':'in_progress','model':'trial','output':[]}
                send({'type':'response.created','response':response},'response.created')
                send({'type':'response.output_item.added','output_index':0,'item':dict(item, arguments='') if function else item},'response.output_item.added')
                if function: send({'type':'response.function_call_arguments.delta','item_id':item['id'],'output_index':0,'delta':json.dumps(args)},'response.function_call_arguments.delta')
                else: send({'type':'response.output_text.delta','item_id':item['id'],'output_index':0,'content_index':0,'delta':'TRIAL_DONE'},'response.output_text.delta')
                send({'type':'response.output_item.done','output_index':0,'item':item},'response.output_item.done')
                response.update(status='completed',output=[item],usage={'input_tokens':1,'output_tokens':1,'total_tokens':2})
                send({'type':'response.completed','response':response},'response.completed')
            else:
                delta=message.copy()
                if function: delta['tool_calls'][0]['index']=0
                common={'id':response_id,'object':'chat.completion.chunk','created':int(time.time()),'model':data.get('model','trial')}
                send(dict(common,choices=[{'index':0,'delta':delta,'finish_reason':None}]))
                send(dict(common,choices=[{'index':0,'delta':{},'finish_reason':'tool_calls' if function else 'stop'}]))
                self.wfile.write(b'data: [DONE]\n\n'); self.wfile.flush()
        else:
            self.send_header('Content-Type','application/json'); self.end_headers()
            self.wfile.write(json.dumps({'id':response_id,'object':'chat.completion','created':int(time.time()),'model':'trial','choices':[{'index':0,'message':message,'finish_reason':'tool_calls' if function else 'stop'}],'usage':{'prompt_tokens':1,'completion_tokens':1,'total_tokens':2}}).encode())
ThreadingHTTPServer(('127.0.0.1',18099),Handler).serve_forever()
