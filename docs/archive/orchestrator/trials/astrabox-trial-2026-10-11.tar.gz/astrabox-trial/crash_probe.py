import argparse,json,time,subprocess,urllib.request,urllib.error,datetime
from pathlib import Path
ap=argparse.ArgumentParser();ap.add_argument('--session',required=True);ap.add_argument('--container',required=True);ap.add_argument('--server',default='rapid-ship-astrabox-trial-server-1');ap.add_argument('--url',default='http://127.0.0.1:18088');ap.add_argument('--no-replay',action='store_true');ap.add_argument('--settle-seconds',type=float,default=0);ap.add_argument('--sleep-seconds',type=int,default=40);args=ap.parse_args()
p=Path(__file__).parent;sid=args.session;base=args.url;container=args.container;events=[]
case='crash-no-replay' if args.no_replay else 'crash-once';marker='crash-count2' if args.no_replay else 'crash-count'
def record(name,data):
 events.append({'event':name,'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'data':data});p.joinpath('crash2-results.json' if args.no_replay else 'crash-results.json').write_text(json.dumps(events,indent=2));print(name,json.dumps(data)[:1800],flush=True)
def req(path,data=None):
 r=urllib.request.Request(base+path,data=None if data is None else json.dumps(data).encode(),headers={'Content-Type':'application/json'})
 with urllib.request.urlopen(r,timeout=10) as s:return json.load(s)
def docker(*args):
 r=subprocess.run(['docker',*args],capture_output=True,text=True);return {'exit':r.returncode,'out':r.stdout,'err':r.stderr}
command=f'printf start >> /workspace/{marker}; sleep {args.sleep_seconds}; printf end >> /workspace/{marker}; cat /workspace/{marker}';payload={'content':'TRIAL_OP='+json.dumps({'command':command}),'client_message_id':case,'permission_mode':'danger-full-access'}
record('turn-start',req('/api/v1/sessions/'+sid+'/turn-inputs',payload))
for _ in range(15):
 r=docker('exec',container,'cat','/workspace/'+marker)
 if r['exit']==0 and r['out']=='start':break
 time.sleep(1)
else:raise RuntimeError('No running command marker')
record('active-marker',r);time.sleep(args.settle_seconds);record('active-session',req('/api/v1/sessions/'+sid))
record('kill-server',docker('kill','--signal','KILL',args.server));time.sleep(2)
record('server-state-after-kill',docker('inspect',args.server,'--format','{{.State.Status}} {{.State.ExitCode}}'))
record('start-server',docker('start',args.server))
for _ in range(50):
 try:record('ready-after-crash',req('/readyz'));break
 except Exception:time.sleep(2)
record('recovered-session',req('/api/v1/sessions/'+sid))
if not args.no_replay:
 try:record('duplicate-input-after-crash',req('/api/v1/sessions/'+sid+'/turn-inputs',payload))
 except urllib.error.HTTPError as e:record('duplicate-input-after-crash',{'http':e.code,'body':e.read().decode()})
else:record('replay-policy','No input replay')
for _ in range(45):
 d=req('/api/v1/sessions/'+sid)['data'];r=docker('exec',container,'cat','/workspace/'+marker)
 if r['out']=='startend' and d['state']=='READY':break
 time.sleep(2)
record('final-file',r);record('final-session',d)
