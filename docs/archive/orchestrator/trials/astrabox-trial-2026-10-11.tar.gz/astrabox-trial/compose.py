import os, subprocess, sys
from pathlib import Path
p=Path(__file__).parent
env={k:v for k,v in os.environ.items() if k in {"PATH","TMPDIR","DOCKER_HOST","DOCKER_CONTEXT"}}
for line in (p/"trial.env").read_text().splitlines():
 k,v=line.split("=",1); env[k]=v
env["ASTRABOX_LOCAL_DATABASE_SECRET_DIR"]=str(p/"secrets")
env["ASTRABOX_PUBLISH_HOST_IP"]=subprocess.check_output(["docker","network","inspect","bridge","--format","{{(index .IPAM.Config 0).Gateway}}"],text=True).strip()
args=["docker","compose","--project-name","rapid-ship-astrabox-trial","--env-file",str(p/"trial.env"),"-f",str(p/"source/containers/compose.yaml"),"-f",str(p/"limits.yaml")]+sys.argv[1:]
raise SystemExit(subprocess.call(args,env=env))
