"""Repeat the observed checks against the scoped AstraBox trial deployment.

Real Codex/containers; model_stub.py supplies deterministic responses.
No model quality claim. This helper consolidates the recorded API steps.
"""
import argparse,json,subprocess,time,urllib.error,urllib.request,uuid
from pathlib import Path
ap=argparse.ArgumentParser();ap.add_argument('--url',default='http://127.0.0.1:18088');ap.add_argument('--server',default='rapid-ship-astrabox-trial-server-1');ap.add_argument('--keep-session',action='store_true');args=ap.parse_args()
root=Path(__file__).parent;observations=[]
def record(name,data):
 observations.append({'event':name,'at':time.time(),'data':data});root.joinpath('results.json').write_text(json.dumps(observations,indent=2));print(name,json.dumps(data),flush=True)
def api(path,data=None,method=None,headers=None):
 r=urllib.request.Request(args.url+path,data=None if data is None else json.dumps(data).encode(),method=method,headers={'Content-Type':'application/json',**(headers or {})})
 with urllib.request.urlopen(r,timeout=30) as q:return json.load(q)
def session(sid):return api('/api/v1/sessions/'+sid)['data']
def wait_ready(sid,timeout=180):
 deadline=time.time()+timeout
 while time.time()<deadline:
  d=session(sid)
  if d['state']=='READY':return d
  if d['state']=='FAILED':raise RuntimeError(d)
  time.sleep(2)
 raise TimeoutError(session(sid))
def docker(*cmd):
 p=subprocess.run(['docker',*cmd],capture_output=True,text=True);return {'exit':p.returncode,'stdout':p.stdout,'stderr':p.stderr}
def shell(container,cmd):return docker('exec',container,'sh','-c',cmd)
def send(sid,cmd,key):
 return api('/api/v1/sessions/'+sid+'/turn-inputs',{'content':'TRIAL_OP='+json.dumps({'command':cmd}),'permission_mode':'danger-full-access','client_message_id':key})
# Disable demo prewarming only inside the caller's dedicated trial deployment.
for a in api('/api/v1/agents')['data']:
 if a.get('created_by')=='system' and a.get('prepared_capacity'):
  payload={k:a[k] for k in ('name','environment_name','version')};payload.update(model='trial',prepared_capacity=0)
  api('/api/v1/agents/'+a['agent_id'],payload,'PUT')
api('/api/v1/admin/environments/trial-codex',{'name':'trial-codex','engine_kind':'codex','enabled':True,'sandbox_tenancy':'conversation','networking':{'type':'limited','allowed_hosts':['host.docker.internal'],'allow_mcp_servers':False}},'PUT')
a=api('/api/v1/agents',{'name':'Lifecycle trial '+uuid.uuid4().hex[:6],'model':'trial','environment_name':'trial-codex','prepared_capacity':0,'system':'Execute the supplied trial operation exactly once; report output.'})['data']['agent_id']
route='/api/v1/agents/'+a+'/conversations';s1=api(route,{})['data']['session_id'];key=uuid.uuid4().hex
s2=api(route,{},headers={'Idempotency-Key':key})['data']['session_id'];s2b=api(route,{},headers={'Idempotency-Key':key})['data']['session_id'];assert s2==s2b;record('conversation-idempotency',s2==s2b)
c1='sandbox-'+wait_ready(s1)['sandbox_id'];c2='sandbox-'+wait_ready(s2)['sandbox_id'];record('containers',[c1,c2])
record('mounts',docker('inspect',c1,'--format','{{json .Mounts}}'))
record('first-turn',send(s1,'printf first-session > /workspace/trial-source.txt; cat /workspace/trial-source.txt','first'))
time.sleep(2);wait_ready(s1);record('source',shell(c1,'cat /workspace/trial-source.txt'));record('separate-workspace',shell(c2,'test ! -e /workspace/trial-source.txt'))
cmd='printf start >> /workspace/long-count; sleep 65; printf end >> /workspace/long-count; cat /workspace/long-count';started=time.time();record('long-start',send(s1,cmd,'long'));record('duplicate-turn',send(s1,cmd,'long'))
record('child-start',send(s2,"sh -c 'sleep 120; touch /workspace/should-not-exist' & echo $! > /workspace/child.pid; wait",'cancel'))
for _ in range(15):
 if shell(c2,'test -e /workspace/child.pid')['exit']==0:break
 time.sleep(1)
time.sleep(2);record('interrupt',api('/api/v1/sessions/'+s2+'/interrupt',{}));time.sleep(4)
record('child-after-interrupt',shell(c2,'pid=$(cat /workspace/child.pid); if test -e /proc/$pid/stat; then cat /proc/$pid/stat; else echo absent; fi'))
record('interrupt-state',session(s2));record('disposal',api('/api/v1/sessions/'+s2,method='DELETE'));record('container-after-disposal',docker('inspect',c2,'--format','{{.State.Status}}'))
wait_ready(s1,150);record('long-elapsed',time.time()-started);record('long-result',shell(c1,'cat /workspace/long-count'));record('long-state',session(s1));record('native-before',shell(c1,'rg --files /home/agent/.codex/sessions'))
record('restart',docker('restart',args.server));time.sleep(3)
for _ in range(50):
 try:
  api('/readyz');break
 except Exception:time.sleep(3)
record('session-after-restart',session(s1));record('resume-turn',send(s1,'cat /workspace/trial-source.txt /workspace/long-count; printf resumed > /workspace/resumed.txt','resume'));time.sleep(3);wait_ready(s1)
record('files-after-restart',shell(c1,'cat /workspace/trial-source.txt /workspace/long-count /workspace/resumed.txt'));record('native-after',shell(c1,'rg --files /home/agent/.codex/sessions'))
if args.keep_session:
 record('retained-trial-session',{'session_id':s1,'container':c1,'agent_id':a})
else:
 record('final-disposal',api('/api/v1/sessions/'+s1,method='DELETE'));api('/api/v1/agents/'+a,method='DELETE')
