# AstraBox runtime probe

This bundle repeats a small runtime trial of AstraBox 0.1.5. It uses real Docker sandboxes and Codex CLI 0.160.0. A deterministic local model stub chooses shell tools; it does **not** evaluate coding quality or any live model provider. All keys in the configuration are synthetic.

The recorded run used macOS ARM64 with OrbStack. See `pins.json` for exact versions. The main worker image is approximately 3.50 GB compressed / 8.68 GB unpacked. Pre-pull it before starting sessions so image-download time is separate from runtime startup.

The service has the documented Docker socket access. Workers receive no host home, SSH, GitHub, cloud, or real provider credentials. The worker receives only the synthetic gateway key used by this probe. The external gateway uses port 18100, so the probe explicitly disables protected model credential delivery; this does not test AstraBox's credential vault. Keep the gateway and API loopback-only.

## Setup

Prerequisites: Git, Python 3.12, uv, and a working Docker Engine with Compose. Use a dedicated directory and keep its contents together. These commands assume macOS/OrbStack; confirm host reachability and socket group for other engines. Do not restart or reconfigure a shared Docker daemon for this probe.

```sh
git clone --branch v0.1.5 --depth 1 https://github.com/Colton-z/AstraBox source
git -C source rev-parse HEAD
# Expected a84cc2b53183702198a87fa7f04fddba2555ff87
uv venv --python 3.12 gateway-venv
uv pip install --python gateway-venv/bin/python --index-url https://pypi.org/simple -r gateway-requirements.txt
python3 source/scripts/ensure_local_database_secrets.py --directory secrets
docker pull ghcr.io/colton-z/astrabox-sandbox-codex@sha256:71c292274d4051a883dc2a916b4180af490ef6a9dfbc494426485942042891da
docker tag ghcr.io/colton-z/astrabox-sandbox-codex@sha256:71c292274d4051a883dc2a916b4180af490ef6a9dfbc494426485942042891da ghcr.io/colton-z/astrabox-sandbox-codex:0.1.5
docker pull opensandbox/egress@sha256:db7345d567b0970f384b8e3fa7a93a71b7f43d4b16bb2009de34096e9a87b3b5
docker tag opensandbox/egress@sha256:db7345d567b0970f384b8e3fa7a93a71b7f43d4b16bb2009de34096e9a87b3b5 opensandbox/egress:v1.1.7
docker pull opensandbox/execd@sha256:6cf7dba2f21f0b536e100563d841ac58a9f31c2b0a081b7ac76796a24d6f47e2
docker tag opensandbox/execd@sha256:6cf7dba2f21f0b536e100563d841ac58a9f31c2b0a081b7ac76796a24d6f47e2 opensandbox/execd:v1.1.0
```

`trial.env` sets `DOCKER_GID=0`, which matched the socket inside the Linux VM in the recorded run. The host Mac's socket group was 20 and did not work inside the container. `compose.py` calculates the observed bridge gateway and uses a scoped secrets directory. It intentionally strips inherited provider credentials from the Compose environment.

Run the stub and gateway in separate terminals from this directory:

```sh
python3 model_stub.py
```

```sh
env -i PATH="$PATH" ./gateway-venv/bin/litellm --config gateway.yaml --host 127.0.0.1 --port 18100
```

Start only the scoped trial project:

```sh
python3 compose.py pull
python3 compose.py up -d --no-build
curl --fail http://127.0.0.1:18088/readyz
```

`limits.yaml` contains trial-specific caps, not upstream defaults. It also uses a 5-second orphan sweep interval; the upstream 600-second orphan grace is unchanged. The recorded ordinary session tests used the default 300-second interval; only the later orphan observation used 5 seconds.

## Run

```sh
python3 probe.py
```

`probe.py` is a diagnostic capture helper consolidating the observed API steps. Its exit code is not a test verdict: review the recorded command IDs, turn status/reason, file contents and Docker inspection results. Except for conversation-ID equality, it does not assert every expected result, and its READY polling can observe an earlier ready state. The published conclusions below come from reviewing the original evidence, not this helper exiting zero. It creates two scoped sessions, captures separate filesystem observations, runs a 65-second command with a duplicate input ID, interrupts a command with a child process, deletes that session, restarts the API container, and captures source plus native Codex conversation observations. It records HTTP responses, command results, and timestamps to `results.json`. The saved `lifecycle2-results.json` and `restart-results.json` are the original observations, not output from a second run of this consolidated helper.

The initial long-job attempt had a bug in the model stub's process-session parser; it is excluded from the valid results. The included stub has the corrected parser and was used for the successful long-job run.

A caller must inspect `last_turn_terminal_reason`: native turn interruption was exposed as `last_turn_status=COMPLETED` with reason `interrupted`. It must also inspect tool exit/output and run its own acceptance checks. A completed model turn is not proof that requested work is done.

Turn interruption left the asynchronous shell child alive. DELETE Session removed its container. The task controller therefore needs a strong cancellation path when no process may remain.

The orphan observation came from an actual cold allocation that outlived the client's timeout while images were downloading. `orphan-observations.json` and the report preserve that timeline. The consolidated helper pre-pulls images and does not inject this cold-pull fault.

## Cleanup

The helper deletes its sessions unless `--keep-session` is used. Inspect the trial installation's remaining sandboxes before shutdown; a delayed allocation may still be within the orphan grace. Remove only confirmed trial resources. Then:

```sh
python3 compose.py down --volumes
```

Stop the two host processes using Ctrl-C in their terminals. Do not use `docker system prune`, delete unrelated containers, or delete shared image layers.

## Controller crash probe

To retain the first session for fault injection, run `probe.py --keep-session` and take its final recorded session/container IDs. Use only that dedicated trial session, with no previous crash marker files. These probes kill and restart the named trial platform container; they do not restart Docker.

```sh
python3 crash_probe.py --session SESSION_ID --container CONTAINER_NAME
python3 crash_probe.py --session SESSION_ID --container CONTAINER_NAME --no-replay --settle-seconds 3 --sleep-seconds 20
```

These scripts capture observations; their exit code is not a pass verdict. The first recorded run preserved one external effect but ended the managed turn FAILED with a conflicting turn-anchor error. The control without client replay also preserved one effect, but failed because the live engine client did not implement output reconnect. See `crash-results.json` and `crash2-results.json`. Do not describe completed-session continuation as successful active-turn crash recovery. Do not blindly retry a failed turn after its external effects have already happened.

After a retained-session probe, DELETE that session through the API before shutting down the scoped stack.

The recorded orphan was automatically destroyed at 20:42:48 UTC, just after 600 seconds since container creation, with sidecar/runtime-volume cleanup and `ownerless_reaped: 1` in the service log. Independent inspection confirmed no such object at 20:42:58. See `orphan-cleanup.log` and `orphan-observations.json`.

The failed live-turn workspace remained inspectable through the public Files API (HTTP 200, `startend`), and was disposed through DELETE Session. `failed-session-file-api.json` and `cleanup.json` record those results.
