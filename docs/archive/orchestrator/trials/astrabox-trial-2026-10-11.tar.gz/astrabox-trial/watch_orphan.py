import argparse,datetime,json,subprocess,time
from pathlib import Path
ap=argparse.ArgumentParser();ap.add_argument('--container',required=True);ap.add_argument('--deadline-seconds',type=int,default=700);args=ap.parse_args()
p=Path(__file__).parent;name=args.container;end=time.time()+args.deadline_seconds;rows=[]
while time.time()<end:
 r=subprocess.run(['docker','inspect',name,'--format','{{.Created}} {{.State.Status}}'],capture_output=True,text=True);row={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit':r.returncode,'state':r.stdout.strip(),'stderr':r.stderr.strip()};rows.append(row);p.joinpath('orphan-observations.json').write_text(json.dumps(rows,indent=2))
 if r.returncode!=0: print(json.dumps(row),flush=True);break
 time.sleep(10)
else:print('Still present at observation deadline',flush=True)
