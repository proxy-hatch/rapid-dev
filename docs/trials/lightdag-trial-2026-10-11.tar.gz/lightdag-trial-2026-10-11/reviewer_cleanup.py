"""Actual reviewer subprocess cancellation and deadline checks; no model calls."""
import asyncio, contextlib, json, os, sys, time, uuid
from pathlib import Path
from trial import (ROOT, IMAGE, Fixture, task, wait_for, CallableVerifier,
                   command, cancellable_command, container_state, host_alive, run_case)

async def check(docker, by_timeout):
    f=Fixture('reviewer-cleanup')
    work=f.root/'reviewer';work.mkdir()
    source='''import json,os,pathlib,subprocess,sys,time
child=subprocess.Popen([sys.executable,'-c','import time; time.sleep(60)'],start_new_session=ESCAPE)
pathlib.Path('pids.json').write_text(json.dumps([os.getpid(),child.pid]))
time.sleep(60)
'''.replace('ESCAPE',str(docker))
    (work/'reviewer.py').write_text(source)
    name='rapid-ship-lightdag-reviewer-'+uuid.uuid4().hex[:10]
    args=([sys.executable,str(work/'reviewer.py')] if not docker else [
        'docker','run','--rm','--name',name,'--label','rapid-ship.trial=lightdag',
        '--network','none','--read-only','--cap-drop','ALL','--security-opt','no-new-privileges',
        '--memory','128m','--cpus','0.5','--pids-limit','32',
        '--user',f'{os.getuid()}:{os.getgid()}','--mount',f'type=bind,src={work},dst=/task',
        '--workdir','/task',IMAGE,'python','reviewer.py'])
    # Native helper command has no cwd parameter; use an explicit child chdir.
    if not docker:
        args=[sys.executable,'-c',f'import os,runpy; os.chdir({str(work)!r}); runpy.run_path("reviewer.py",run_name="__main__")']
    cleanup={}
    async def verifier(request):
        (work/'pids.json').unlink(missing_ok=True)
        try:
            operation=cancellable_command(args,lambda:f.dag.get_run('run').status.value!='running',timeout=30)
            if by_timeout:
                # Start the verification deadline once the fixture proves its child exists.
                pending=asyncio.create_task(operation)
                try:
                    await wait_for(lambda:(work/'pids.json').exists(),timeout=30)
                    await asyncio.wait_for(pending,.3)
                finally:
                    pending.cancel()
                    with contextlib.suppress(asyncio.CancelledError): await pending
            else: await operation
            return True
        finally:
            if docker:
                await command('docker','rm','--force',name)
                cleanup['container_gone']=await container_state(name) is None
            else:
                pids=json.loads((work/'pids.json').read_text())
                cleanup['process_tree_gone']=all(not host_alive(pid) for pid in pids)
    f.dag.verifiers['independent']=CallableVerifier('independent',verifier,timeout=40)
    f.create([task('candidate',.01)])
    runner=asyncio.create_task(f.dag.arun('run'))
    await wait_for(lambda:(work/'pids.json').exists(),timeout=30)
    start=time.monotonic()
    if not by_timeout: f.dag.cancel('run','cancel actual reviewer subprocess')
    with contextlib.suppress(asyncio.CancelledError): await runner
    expected='failed' if by_timeout else 'cancelled'
    assert f.dag.get_run('run').status.value==expected
    assert not f.store.list_artifacts('run')
    assert cleanup and all(cleanup.values())
    result=f.snapshot();result.update(cleanup=cleanup,stop_seconds=round(time.monotonic()-start,3),
        mechanism='supervised reviewer adapter; native CallableVerifier alone does not observe cancellation')
    f.close();return result

async def main():
    values=[]
    for name,docker,timeout in [('native_reviewer_cancel',False,False),
                               ('container_reviewer_cancel',True,False),
                               ('native_reviewer_timeout',False,True),
                               ('container_reviewer_timeout',True,True)]:
        values.append(await run_case(name,lambda:check(docker,timeout)))
    return 1 if any(value['status']!='pass' for value in values) else 0
if __name__=='__main__': sys.exit(asyncio.run(main()))
