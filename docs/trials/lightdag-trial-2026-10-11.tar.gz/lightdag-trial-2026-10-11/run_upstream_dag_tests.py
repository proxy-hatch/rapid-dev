"""Run byte-identical pinned upstream DAG tests against the installed wheel."""
import argparse, hashlib, importlib.metadata, json, os, shutil, subprocess, sys
from pathlib import Path
ROOT=Path(__file__).resolve().parent
PIN='8318a5d7cb7a573b6ee63ed5e10d0d23bf10466f'
TESTS=['test_lightdag.py','test_dag_store.py','test_dag_process_recovery.py']
def main():
 parser=argparse.ArgumentParser();parser.add_argument('--source-dir',default='/tmp/rapid-dev-lightagent-v011-research')
 source=Path(parser.parse_args().source_dir)
 revision=subprocess.check_output(['git','-C',str(source),'rev-parse','HEAD'],text=True).strip()
 assert revision==PIN,revision
 stage=ROOT/'upstream-tests';(stage/'tests').mkdir(parents=True,exist_ok=True)
 hashes={}
 for name in TESTS:
  src=source/'tests'/name;dst=stage/'tests'/name;shutil.copy2(src,dst)
  assert src.read_bytes()==dst.read_bytes()
  hashes[name]=hashlib.sha256(src.read_bytes()).hexdigest()
 env={'PATH':os.environ['PATH'],'HOME':str(ROOT/'empty-home'),'PYTEST_DISABLE_PLUGIN_AUTOLOAD':'1'}
 probe=subprocess.run([sys.executable,'-I','-c','import LightAgent,json; print(json.dumps({"package_file":LightAgent.__file__}))'],
      cwd=stage,env=env,text=True,capture_output=True,check=True)
 location=json.loads(probe.stdout)['package_file']
 assert '/site-packages/LightAgent/' in location,location
 argv=[sys.executable,'-I','-m','pytest','--import-mode=importlib','-q',
       '--junitxml='+str(ROOT/'upstream-dag-tests.xml'),*[str(stage/'tests'/name) for name in TESTS]]
 result=subprocess.run(argv,cwd=stage,env=env,text=True,capture_output=True)
 (ROOT/'upstream-dag-tests.stdout').write_text(result.stdout)
 (ROOT/'upstream-dag-tests.stderr').write_text(result.stderr)
 metadata={'upstream_commit':PIN,'lightagent':importlib.metadata.version('LightAgent'),
     'pytest':importlib.metadata.version('pytest'),'installed_package_file':location,
     'source_test_sha256':hashes,'command':argv,'exit_code':result.returncode,
     'test_import_policy':'Unmodified tests copied away from source; isolated Python importlib mode uses installed package, including subprocess test'}
 (ROOT/'upstream-dag-tests.json').write_text(json.dumps(metadata,indent=2))
 print(result.stdout,end='');print(result.stderr,end='',file=sys.stderr)
 print(json.dumps(metadata))
 return result.returncode
if __name__=='__main__': sys.exit(main())
