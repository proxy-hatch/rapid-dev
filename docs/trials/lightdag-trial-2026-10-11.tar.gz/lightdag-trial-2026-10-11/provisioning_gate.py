"""Small create/ack/start experiment; not a production resource manager."""
import asyncio, contextlib, json, os, shutil, sys, time, uuid
from pathlib import Path
from trial import (ROOT, IMAGE, Fixture, TaskOutcome, task, command, cancellable_command,
                   container_state, wait_for, run_case)

class ProvisioningWorker:
    def __init__(self,root,*,ack_delay=0,ack_timeout=15):
        self.root=root;self.ack_delay=ack_delay;self.ack_timeout=ack_timeout
        self.pending=None;self.container_id=None;self.create_count=0
        self.intent_path=root/'resource-intent.json'
        self.intent=json.loads(self.intent_path.read_text()) if self.intent_path.exists() else {}
        self.name=self.intent.get('name') or 'rapid-ship-lightdag-provision-'+uuid.uuid4().hex[:10]
        self.work=root/'provision-worker';self.work.mkdir(exist_ok=True)
        shutil.copy2(ROOT/'harness.py',self.work/'harness.py')
    def record(self,state,**extra):
        self.intent.update(state=state,name=self.name,**extra)
        temporary=self.intent_path.with_suffix('.tmp')
        with temporary.open('w') as stream:
            json.dump(self.intent,stream);stream.flush();os.fsync(stream.fileno())
        os.replace(temporary,self.intent_path)
    async def create(self):
        self.create_count+=1
        args=['docker','create','--name',self.name,'--label','rapid-ship.trial=lightdag',
            '--network','none','--read-only','--cap-drop','ALL','--security-opt','no-new-privileges',
            '--pids-limit','32','--memory','128m','--cpus','0.5',
            '--user',f'{os.getuid()}:{os.getgid()}','--tmpfs','/tmp:rw,nosuid,nodev,size=8m',
            '--mount',f'type=bind,src={self.work},dst=/task','--workdir','/task',
            IMAGE,'python','-c',
            'import json,pathlib,subprocess,sys,time; '
            'p=subprocess.Popen([sys.executable,"-c","import time;time.sleep(60)"],start_new_session=True); '
            'pathlib.Path("ready.json").write_text(json.dumps({"child":p.pid})); time.sleep(60)']
        rc,out,err=await command(*args,timeout=30)
        if rc!=0: raise RuntimeError('create outcome not accepted: '+err[:100])
        # Fault injection: daemon created the container but its acknowledgement is delayed.
        # The caller intentionally cannot treat this as known ownership until return.
        await asyncio.sleep(self.ack_delay)
        cid=out.strip()
        if len(cid)!=64 or any(c not in '0123456789abcdef' for c in cid):
            raise RuntimeError('invalid create acknowledgement')
        return cid
    async def cleanup_known(self):
        if not self.container_id: raise RuntimeError('creation outcome is still uncertain')
        self.record('removing',container_id=self.container_id)
        rc,out,err=await command('docker','rm','--force',self.container_id,timeout=30)
        if await container_state(self.name) is not None:
            raise RuntimeError('known container still exists')
        self.record('removed',container_id=self.container_id)
    async def reconcile_acknowledged(self):
        # Explicit recovery step: an actual create acknowledgement is required here.
        # An empty inspect result alone is insufficient to settle an in-flight create.
        self.container_id=await self.pending
        await self.cleanup_known()
    async def execute(self,context):
        if self.intent_path.exists(): self.intent=json.loads(self.intent_path.read_text())
        if self.intent.get('state') in {'creating','uncertain','removing'}:
            return TaskOutcome.blocked('resource creation/cleanup is uncertain; reconcile before retry')
        self.record('creating',attempt_id=context.attempt.attempt_id)
        self.pending=asyncio.create_task(self.create())
        try:
            self.container_id=await asyncio.wait_for(asyncio.shield(self.pending),self.ack_timeout)
        except Exception as error:
            self.record('uncertain',reason=type(error).__name__)
            return TaskOutcome.blocked('create acknowledgement missing; no start or retry until reconciled')
        self.record('created',container_id=self.container_id)
        if context.cancellation_token.cancelled:
            await self.cleanup_known()
            raise asyncio.CancelledError('cancelled while waiting for create acknowledgement')
        try:
            self.record('running',container_id=self.container_id)
            rc,out,err=await cancellable_command(['docker','start','--attach',self.container_id],
                lambda:context.cancellation_token.cancelled,timeout=30)
            if rc: raise RuntimeError('worker did not complete successfully')
            return TaskOutcome.candidate(out)
        finally:
            try: await self.cleanup_known()
            except Exception as error:
                self.record('uncertain',reason=type(error).__name__)
                # Block automatic retry when resource cleanup cannot be confirmed.
                return TaskOutcome.blocked('cleanup uncertain; reconcile resource before retry')

async def delayed_create_cancel():
    f=Fixture('provision-cancel')
    worker=ProvisioningWorker(f.root,ack_delay=1.5)
    f.factory.register('external-cli',worker);f.create([task('cancel-during-create')])
    runner=asyncio.create_task(f.dag.arun('run'))
    await wait_for(lambda:worker.pending is not None)
    f.dag.cancel('run','cancel before create acknowledgement')
    with contextlib.suppress(asyncio.CancelledError): await runner
    assert worker.intent['state']=='removed' and await container_state(worker.name) is None
    assert worker.create_count==1 and not (worker.work/'ready.json').exists()
    result={'root':str(f.root),'run':f.dag.get_run('run').status.value,'resource':worker.intent,
            'create_calls':worker.create_count,'worker_started':False}
    f.close();return result

async def uncertain_create_blocks_retry():
    f=Fixture('provision-uncertain')
    worker=ProvisioningWorker(f.root,ack_delay=1.5,ack_timeout=.2)
    f.factory.register('external-cli',worker);f.create([task('uncertain-create')])
    result=await f.dag.arun('run')
    assert result.status.value=='blocked' and worker.intent['state']=='uncertain'
    for _ in range(2): assert (await f.dag.resume('run')).status.value=='blocked'
    assert worker.create_count==1 and f.dag.get_task('run','uncertain-create').state.attempt_count==1
    assert not (worker.work/'ready.json').exists()
    restarted=ProvisioningWorker(f.root)
    assert restarted.intent['state']=='uncertain' and restarted.name==worker.name
    f.factory.register('external-cli',restarted)
    f.dag.resolve_blocker('run','uncertain-create','trial explicit unblock before reconciliation')
    assert (await f.dag.resume('run')).status.value=='blocked'
    assert restarted.create_count==0
    await worker.reconcile_acknowledged()
    assert worker.intent['state']=='removed' and await container_state(worker.name) is None
    detail={'root':str(f.root),'run':'blocked','create_calls':worker.create_count,
            'repeated_resumes':2,'restarted_adapter_prevented_create':True,'worker_started':False,'reconciled_resource':worker.intent}
    f.close();return detail

async def running_container_cancel():
    f=Fixture('provision-running')
    worker=ProvisioningWorker(f.root)
    f.factory.register('external-cli',worker);f.create([task('cancel-running')])
    runner=asyncio.create_task(f.dag.arun('run'))
    await wait_for(lambda:(worker.work/'ready.json').exists(),timeout=30)
    f.dag.cancel('run','cancel running container')
    with contextlib.suppress(asyncio.CancelledError): await runner
    assert worker.intent['state']=='removed' and await container_state(worker.name) is None
    assert not f.store.list_artifacts('run')
    result={'root':str(f.root),'run':f.dag.get_run('run').status.value,'resource':worker.intent,
            'worker_child_started':True}
    f.close();return result

async def main():
    values=[]
    for name,operation in [('create_ack_delayed_cancel',delayed_create_cancel),
                           ('uncertain_create_blocks_retry',uncertain_create_blocks_retry),
                           ('created_started_container_cancel',running_container_cancel)]:
        values.append(await run_case(name,operation))
    return 1 if any(r['status']!='pass' for r in values) else 0
if __name__=='__main__': sys.exit(asyncio.run(main()))
