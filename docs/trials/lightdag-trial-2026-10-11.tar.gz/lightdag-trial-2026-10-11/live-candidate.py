def chunked(items, size):
    if size <= 0:
        raise ValueError("size must be greater than zero")
    return [items[i:i + size] for i in range(0, len(items), size)]