import json
from candidate import chunked
items=[1,2,3,4,5]
assert chunked(items,2)==[[1,2],[3,4],[5]]
assert items==[1,2,3,4,5]
assert chunked([],2)==[]
assert chunked([1,2],5)==[[1,2]]
assert chunked([1,2],1)==[[1],[2]]
for size in [0,-1]:
 try: chunked([1],size)
 except ValueError: pass
 else: raise AssertionError('expected ValueError')
result=chunked(items,2)
result[0][0]=99
assert items[0]==1
print(json.dumps({'checks':'passed'}))
