"""Recheck preserved live output without spending another model call."""
import asyncio, json, os, shutil, signal, sys, time, uuid
from pathlib import Path
ROOT=Path(__file__).resolve().parent
async def main():
 record=json.loads((ROOT/'live-agy-initial-result.json').read_text())
 run_root=Path(record['lightdag']['root'])
 if not run_root.is_absolute(): run_root=ROOT/run_root
 check=run_root/'verification'
 if not check.exists():
  check=ROOT/'verification';check.mkdir(exist_ok=True)
  shutil.copy2(ROOT/'live-candidate.py',check/'candidate.py')
  shutil.copy2(ROOT/'live-check.py',check/'check.py')
 name='rapid-ship-lightdag-recheck-'+uuid.uuid4().hex[:8]
 image='python@sha256:2d9aefe2fef018a7eb2c13064c89c71929800fd2e5dccdbf52ea5da5bb8d929a'
 argv=['docker','run','--rm','--name',name,'--label','rapid-ship.trial=lightdag',
  '--network','none','--read-only','--cap-drop','ALL','--security-opt','no-new-privileges',
  '--pids-limit','32','--memory','128m','--cpus','0.5','--user',f'{os.getuid()}:{os.getgid()}',
  '--tmpfs','/tmp:rw,nosuid,nodev,size=8m','--mount',f'type=bind,src={check},dst=/check,readonly',
  '--workdir','/check',image,'python','-B','check.py']
 start=time.monotonic()
 process=await asyncio.create_subprocess_exec(*argv,stdout=asyncio.subprocess.PIPE,stderr=asyncio.subprocess.PIPE,start_new_session=True)
 try:
  out,err=await asyncio.wait_for(process.communicate(),120)
  result={'kind':'preserved-live-candidate-verification','new_model_calls':0,
          'elapsed':round(time.monotonic()-start,3),'exit_code':process.returncode,
          'stdout':out.decode(),'stderr':err.decode(),'argv':argv}
 except asyncio.TimeoutError:
  process.kill();await process.wait()
  result={'kind':'preserved-live-candidate-verification','new_model_calls':0,
          'elapsed':round(time.monotonic()-start,3),'error':'container command exceeded 120s'}
 finally:
  if process.returncode is None:
   os.killpg(process.pid,signal.SIGKILL);await process.wait()
  cleanup=await asyncio.create_subprocess_exec('docker','rm','--force',name,stdout=asyncio.subprocess.DEVNULL,stderr=asyncio.subprocess.DEVNULL)
  try: await asyncio.wait_for(cleanup.wait(),20)
  except asyncio.TimeoutError: cleanup.kill();await cleanup.wait()
 try:
  passed=result.get('exit_code')==0 and json.loads(result.get('stdout',''))=={'checks':'passed'}
 except (ValueError,TypeError): passed=False
 result['status']='pass' if passed else 'fail'
 (ROOT/'live-candidate-verification.json').write_text(json.dumps(result,indent=2))
 print(json.dumps(result),flush=True)
 return 0 if passed else 1
if __name__=='__main__': sys.exit(asyncio.run(main()))
