"""Credential-free deterministic CLI stand-in; not a coding model."""
import json, os, pathlib, socket, subprocess, sys, time
request = json.load(sys.stdin)
root = pathlib.Path.cwd()
child_code = 'import pathlib,time; p=pathlib.Path("ticks.txt");\nwhile True:\n with p.open("a") as f: f.write("tick\\n")\n time.sleep(.1)'
child = subprocess.Popen([sys.executable, '-c', child_code], start_new_session=request.get('escape_group', False))
(root/'child.pid').write_text(str(child.pid))
(root/'parent.pid').write_text(str(os.getpid()))
isolation = {'docker_socket': pathlib.Path('/var/run/docker.sock').exists(),
             'credential_env': any(k.endswith(('_API_KEY', '_TOKEN', '_SECRET_ACCESS_KEY')) for k in os.environ)}
if request.get('isolation'):
    try:
        pathlib.Path('/rapid-ship-write-probe').write_text('forbidden')
        isolation['root_write_blocked'] = False
    except OSError:
        isolation['root_write_blocked'] = True
    try:
        with socket.create_connection(('1.1.1.1', 443), timeout=.2):
            isolation['external_network_blocked'] = False
    except OSError:
        isolation['external_network_blocked'] = True
try:
    time.sleep(request['duration'])
    print(json.dumps({'task': request['task'], 'attempt':request['attempt'],
                      'model':request['model'], 'isolation':isolation}), flush=True)
finally:
    child.terminate()
    child.wait()
