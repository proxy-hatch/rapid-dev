"""Negative controls and a public-API single-flight workaround."""
import asyncio, contextlib, json, sys, time
from trial import Fixture, task, wait_for, events, run_case

async def concurrent_resume_control():
    f=Fixture('same-owner-resume');f.create([task('once',2)])
    first=asyncio.create_task(f.dag.arun('run'))
    await wait_for(lambda:bool(f.factory.resources))
    second=await f.dag.resume('run')
    first_error=None
    try: await first
    except BaseException as error: first_error=type(error).__name__
    assert second.status.value=='blocked' and first_error=='CancelledError'
    assert sum(e['event']=='dispatch' for e in events(f.root))==1
    assert not f.store.list_artifacts('run')
    detail=f.snapshot()
    detail.update(second_status=second.status.value,first_error=first_error,
                  dispatch_count=sum(e['event']=='dispatch' for e in events(f.root)),
                  interpretation='Native concurrent resume with the same scheduler identity is not single-flight')
    f.close();return detail

async def single_flight_workaround():
    f=Fixture('single-flight');f.create([task('once',.3)])
    active={}
    async def resume(run_id):
        if run_id not in active:
            active[run_id]=asyncio.create_task(f.dag.resume(run_id))
        return await asyncio.shield(active[run_id])
    results=await asyncio.gather(resume('run'),resume('run'),resume('run'))
    assert all(result.success for result in results)
    assert sum(e['event']=='dispatch' for e in events(f.root))==1
    detail=f.snapshot();detail.update(requests=3,dispatch_count=1)
    f.close();return detail

async def review_cancel_control():
    f=Fixture('review-cancel',review_delay=2);f.create([task('review',.05)])
    first=asyncio.create_task(f.dag.arun('run'))
    await wait_for(lambda:any(e['event']=='review_start' for e in events(f.root)))
    started=time.monotonic();f.dag.cancel('run','cancel during review')
    await first
    assert f.dag.get_run('run').status.value=='cancelled'
    assert not f.store.list_artifacts('run')
    assert time.monotonic()-started>1
    detail=f.snapshot();detail.update(cancel_to_return_seconds=round(time.monotonic()-started,3),
        interpretation='Plain CallableVerifier continues until return/timeout; reviewer subprocess adapter needs cancellation handling')
    f.close();return detail

async def main():
    results=[]
    for name,operation in [('same_owner_concurrent_resume_control',concurrent_resume_control),
                           ('single_flight_resume_workaround',single_flight_workaround),
                           ('review_cancel_control',review_cancel_control)]:
        results.append(await run_case(name,operation))
    return 1 if any(r["status"]!="pass" for r in results) else 0
if __name__=='__main__': sys.exit(asyncio.run(main()))
