"""LightDAG public-API integration trial. Run with isolated .venv Python."""
from __future__ import annotations
import argparse, asyncio, contextlib, hashlib, importlib.metadata, json, os
from pathlib import Path
import shutil, signal, subprocess, sys, time, uuid
from LightAgent.capabilities import CapabilityRisk, PermissionSet
from LightAgent.security import SecurityContext
from LightAgent.dag import (LightDAG, DAGConfig, DAGError, SqliteTaskGraphStore,
    LocalArtifactStore, TaskSpec, TaskOutcome, CallableVerifier, RegistryWorkerFactory,
    VerificationRequest)
ROOT = Path(__file__).resolve().parent
IMAGE = 'python@sha256:2d9aefe2fef018a7eb2c13064c89c71929800fd2e5dccdbf52ea5da5bb8d929a'
SAFE_ENV = {'PATH':'/opt/homebrew/bin:/usr/local/bin:/usr/bin:/bin', 'HOME':str(ROOT/'empty-home')}
(ROOT/'empty-home').mkdir(exist_ok=True)
CTX = SecurityContext(user_id='trial',tenant_id='trial',project_id='trial',
    permissions=PermissionSet(allowed=frozenset({'dag.task.execute'}),max_risk=CapabilityRisk.SENSITIVE))

def trace(root, event, **data):
    with (root/'trace.jsonl').open('a') as f:
        f.write(json.dumps({'event':event, 'at':time.time(), **data})+'\n')

def events(root):
    p=root/'trace.jsonl'
    return [json.loads(s) for s in p.read_text().splitlines()] if p.exists() else []

async def command(*args, timeout=30):
    p=await asyncio.create_subprocess_exec(*args,stdout=asyncio.subprocess.PIPE,stderr=asyncio.subprocess.PIPE,env=SAFE_ENV,start_new_session=True)
    try:
        out,err=await asyncio.wait_for(p.communicate(),timeout)
        return p.returncode,out.decode(),err.decode()
    finally:
        if p.returncode is None:
            with contextlib.suppress(ProcessLookupError): os.killpg(p.pid,signal.SIGKILL)
            await p.wait()

async def cancellable_command(args, should_cancel, *, timeout=30):
    operation=asyncio.create_task(command(*args,timeout=timeout))
    async def watch():
        while not should_cancel():
            await asyncio.sleep(.05)
    watcher=asyncio.create_task(watch())
    try:
        done,_=await asyncio.wait({operation,watcher},return_when=asyncio.FIRST_COMPLETED)
        if watcher in done: raise asyncio.CancelledError('run cancelled during verification')
        return await operation
    finally:
        watcher.cancel();operation.cancel()
        for pending in [watcher,operation]:
            with contextlib.suppress(asyncio.CancelledError): await pending

def task(task_id, duration=.1, model='deterministic-model-A', **metadata):
    return TaskSpec(task_id=task_id, goal='Exercise external CLI runtime',
        acceptance_contract={'task':task_id,'model':model},worker_key='external-cli',verifier_key='independent',
        metadata={'duration':duration,'model':model,**metadata})

class ExternalWorker:
    def __init__(self, factory): self.factory=factory
    async def execute(self, context):
        f=self.factory
        attempt=context.attempt.attempt_id
        work=f.root/'workers'/attempt
        work.mkdir(parents=True)
        shutil.copy2(ROOT/'harness.py',work/'harness.py')
        name='rapid-ship-lightdag-'+attempt[:16]
        metadata=dict(context.task.spec.metadata)
        duration=metadata['duration']
        if metadata.get('quick_retry') and context.attempt.attempt_no>1: duration=.05
        payload=json.dumps({'task':context.task.spec.task_id,'attempt':context.attempt.attempt_no,
            'duration':duration,'model':metadata['model'],'escape_group':f.docker,
            'isolation':f.docker}).encode()
        if f.docker:
            argv=['docker','run','--rm','-i','--name',name,'--label','rapid-ship.trial=lightdag',
                '--network','none','--read-only','--cap-drop','ALL','--security-opt','no-new-privileges',
                '--pids-limit','64','--memory','128m','--cpus','0.5','--user',f'{os.getuid()}:{os.getgid()}',
                '--tmpfs','/tmp:rw,nosuid,nodev,size=16m','--mount',f'type=bind,src={work},dst=/task',
                '--workdir','/task',IMAGE,'python','/task/harness.py']
        else:
            argv=[sys.executable,str(work/'harness.py')]
        proc=await asyncio.create_subprocess_exec(*argv,cwd=work,env=SAFE_ENV,start_new_session=True,
            stdin=asyncio.subprocess.PIPE,stdout=asyncio.subprocess.PIPE,stderr=asyncio.subprocess.PIPE)
        identity={'pid':proc.pid,'container':name if f.docker else None,'work':str(work),
                  'task':context.task.spec.task_id,'attempt':context.attempt.attempt_no,'attempt_id':attempt}
        (work/'resource.json').write_text(json.dumps(identity))
        f.resources.append(identity)
        trace(f.root,'dispatch',**identity,model=metadata['model'])
        operation=asyncio.create_task(proc.communicate(payload))
        async def wait_cancel():
            while not context.cancellation_token.cancelled:
                await asyncio.sleep(.05)
            raise asyncio.CancelledError(context.cancellation_token.reason)
        watcher=asyncio.create_task(wait_cancel()) if f.observe_cancel else None
        try:
            done,_=await asyncio.wait({operation,watcher} if watcher else {operation},
                timeout=f.worker_timeout,return_when=asyncio.FIRST_COMPLETED)
            if not done: raise TimeoutError('external worker deadline exceeded')
            if watcher in done: await watcher
            stdout,stderr=await operation
            if proc.returncode: raise RuntimeError(f'external worker exit {proc.returncode}: {stderr.decode()[:100]}')
            value=json.loads(stdout)
            trace(f.root,'worker_completed',task=context.task.spec.task_id,attempt=context.attempt.attempt_no)
            return TaskOutcome.candidate(json.dumps(value,sort_keys=True))
        finally:
            if watcher:
                watcher.cancel()
                with contextlib.suppress(asyncio.CancelledError): await watcher
            if f.docker:
                await command('docker','rm','--force',name)
            if proc.returncode is None:
                with contextlib.suppress(ProcessLookupError): os.killpg(proc.pid,signal.SIGTERM)
                try: await asyncio.wait_for(proc.wait(),1)
                except asyncio.TimeoutError:
                    with contextlib.suppress(ProcessLookupError): os.killpg(proc.pid,signal.SIGKILL)
                    await proc.wait()
            operation.cancel()
            with contextlib.suppress(asyncio.CancelledError): await operation
            trace(f.root,'worker_reaped',task=context.task.spec.task_id,attempt=context.attempt.attempt_no,
                  returncode=proc.returncode)

class AdapterFactory(RegistryWorkerFactory):
    """Ordinary application integration, no upstream modifications/private calls."""
    def __init__(self, root, store, config, owner, *, docker=False, heartbeat=True,
                 worker_timeout=80, observe_cancel=True):
        super().__init__()
        self.root,self.store,self.config,self.owner=root,store,config,owner
        self.docker,self.heartbeat=docker,heartbeat
        self.worker_timeout,self.observe_cancel=worker_timeout,observe_cancel
        self.resources=[]; self.beats={}; self.renewals=0; self.renewal_enabled=True
        self.register('external-cli',ExternalWorker(self))
    async def create(self,key,context):
        worker=await super().create(key,context)
        if self.heartbeat:
            async def beat():
                try:
                    while True:
                        await asyncio.sleep(min(.5,self.config.task_lease_seconds/4))
                        if not self.renewal_enabled: continue
                        run=self.store.get_run(context.run.run_id)
                        current=self.store.get_task(context.run.run_id,context.task.spec.task_id)
                        if run.status.value!='running':
                            context.cancellation_token.cancel('run stopped'); return
                        if current.state.active_attempt_id!=context.attempt.attempt_id:
                            return
                        self.store.renew_scheduler_lease(run.run_id,self.owner,context.run.scheduler_epoch,
                                                         self.config.scheduler_lease_seconds)
                        self.store.renew_attempt(context.attempt.attempt_id,context.attempt.lease_epoch,
                                                 self.config.task_lease_seconds)
                        self.renewals+=1
                except DAGError as error:
                    trace(self.root,'renewal_lost',error=str(error))
                    context.cancellation_token.cancel('lease renewal failed')
            self.beats[context.attempt.attempt_id]=asyncio.create_task(beat())
        return worker
    async def release(self,worker,context):
        beat=self.beats.pop(context.attempt.attempt_id,None)
        if beat:
            beat.cancel()
            with contextlib.suppress(asyncio.CancelledError): await beat
        await super().release(worker,context)

class Fixture:
    def __init__(self,name,*,lease=4,concurrency=2,reviews=1,review_delay=.1,
                 owner=None,docker=False,heartbeat=True,worker_timeout=80,observe_cancel=True,root=None):
        self.root=Path(root) if root else ROOT/'runs'/(name+'-'+uuid.uuid4().hex[:8])
        self.root.mkdir(parents=True,exist_ok=True)
        self.store=SqliteTaskGraphStore(self.root/'state.db')
        self.config=DAGConfig(task_lease_seconds=lease,scheduler_lease_seconds=lease,
            max_concurrency=concurrency,verification_concurrency=reviews,max_attempts_per_task=2)
        self.owner=owner or uuid.uuid4().hex
        self.factory=AdapterFactory(self.root,self.store,self.config,self.owner,docker=docker,
            heartbeat=heartbeat,worker_timeout=worker_timeout,observe_cancel=observe_cancel)
        async def verifier(request):
            trace(self.root,'review_start',task=request.task.spec.task_id,attempt=request.attempt.attempt_no)
            await asyncio.sleep(review_delay)
            value=json.loads(request.candidate_content)
            valid=value['task']==request.task.spec.task_id and value['model']==request.task.spec.metadata['model']
            if docker:
                check=value['isolation']
                valid=valid and not check['docker_socket'] and not check['credential_env'] and check['root_write_blocked'] and check['external_network_blocked']
            trace(self.root,'review_end',task=request.task.spec.task_id,attempt=request.attempt.attempt_no)
            return valid
        self.dag=LightDAG(store=self.store,config=self.config,worker_factory=self.factory,
            artifact_store=LocalArtifactStore(self.root/'artifacts'),scheduler_id=self.owner,
            verifiers={'independent':CallableVerifier('independent',verifier,timeout=max(5,review_delay+1))})
    def create(self,tasks): self.dag.create_run(tasks,run_id='run',context=CTX)
    def snapshot(self):
        return {'run':self.dag.get_run('run').status.value,
                'tasks':[{ 'id':t.spec.task_id,'state':t.state.status.value,'attempts':t.state.attempt_count}
                         for t in self.dag.list_tasks('run')],
                'artifacts':len(self.store.list_artifacts('run')),
                'renewals':self.factory.renewals,'root':str(self.root)}
    def close(self): self.store.close()

async def wait_for(predicate,timeout=10):
    deadline=time.monotonic()+timeout
    while time.monotonic()<deadline:
        if predicate(): return
        await asyncio.sleep(.05)
    raise TimeoutError('condition did not become true')

def host_alive(pid):
    result=subprocess.run(['ps','-o','stat=','-p',str(pid)],capture_output=True,text=True)
    return result.returncode==0 and bool(result.stdout.strip()) and not result.stdout.strip().startswith('Z')

async def container_state(name):
    rc,out,err=await command('docker','container','inspect','--format','{{json .State}}',name)
    if rc==0:
        state=json.loads(out)
        if not isinstance(state,dict) or not isinstance(state.get('Running'),bool):
            raise RuntimeError('unexpected Docker inspect state')
        return state
    missing={f'Error response from daemon: No such container: {name}',
             f'Error: No such container: {name}'}
    if rc==1 and not out.strip() and err.strip() in missing:
        return None
    raise RuntimeError(f'Docker inspection failed: exit={rc}, stderr={err[:200]}')

async def resources_stopped(resources):
    result=[]
    for resource in resources:
        if resource['container']:
            alive=await container_state(resource['container']) is not None
        else:
            p=Path(resource['work'])/'child.pid'
            alive=host_alive(resource['pid']) or (p.exists() and host_alive(int(p.read_text())))
        result.append(not alive)
    return all(result)

async def reap_orphans(root):
    count=0
    for record in (root/'workers').glob('*/resource.json'):
        resource=json.loads(record.read_text())
        if resource['container']:
            state=await container_state(resource['container'])
            if state is not None:
                await command('docker','rm','--force',resource['container'])
                if await container_state(resource['container']) is not None:
                    raise RuntimeError('orphan container was not removed')
                count+=1
        elif host_alive(resource['pid']):
            with contextlib.suppress(ProcessLookupError): os.killpg(resource['pid'],signal.SIGKILL)
            count+=1
    return count

async def long_run():
    f=Fixture('long-run',docker=True,lease=4,review_delay=2)
    f.create([task('long-a',65),task('long-b',65,model='deterministic-model-B')])
    result=await f.dag.arun('run')
    assert result.success and f.factory.renewals>20
    reviews=[e for e in events(f.root) if e['event']=='review_start']
    ends=[e for e in events(f.root) if e['event']=='review_end']
    assert len(reviews)==2 and reviews[1]['at']>=ends[0]['at']
    assert await resources_stopped(f.factory.resources)
    value=f.snapshot();value['review_queue_seconds']=round(reviews[1]['at']-reviews[0]['at'],3)
    value['isolation_checked_by_reviewer']=True
    f.close();return value

async def timeout_tree(docker):
    f=Fixture('timeout-'+str(docker),docker=docker,worker_timeout=5 if docker else 1)
    f.create([task('timeout',30)])
    result=await f.dag.arun('run')
    assert result.status.value=='failed'
    assert len(f.factory.resources)==2 and await resources_stopped(f.factory.resources)
    assert all(Path(r['work'],'child.pid').exists() for r in f.factory.resources)
    value=f.snapshot();value['all_process_trees_stopped']=True;f.close();return value

async def cancel_tree(docker):
    f=Fixture('cancel-'+str(docker),docker=docker)
    f.create([task('cancel',30)])
    runner=asyncio.create_task(f.dag.arun('run'))
    await wait_for(lambda:any(Path(r['work'],'child.pid').exists() for r in f.factory.resources))
    start=time.monotonic();f.dag.cancel('run','trial cancellation')
    with contextlib.suppress(asyncio.CancelledError): await runner
    elapsed=time.monotonic()-start
    assert await resources_stopped(f.factory.resources)
    assert f.dag.get_run('run').status.value=='cancelled'
    assert not f.store.list_artifacts('run')
    value=f.snapshot();value.update(all_process_trees_stopped=True,cancel_seconds=round(elapsed,3))
    f.close();return value

async def duplicates():
    f=Fixture('duplicates');f.create([task('once',1)])
    other=Fixture('duplicates',root=f.root)
    first=asyncio.create_task(f.dag.arun('run'))
    await wait_for(lambda:bool(f.factory.resources))
    try: await other.dag.arun('run')
    except DAGError as e: rejected=e.code=='LA-DAG-LEASE-REJECTED'
    else: rejected=False
    assert rejected
    await first
    for _ in range(3): assert (await other.dag.resume('run')).success
    dispatches=[e for e in events(f.root) if e['event']=='dispatch']
    assert len(dispatches)==1
    value=f.snapshot();value.update(second_scheduler_rejected=True,dispatch_count=len(dispatches),resumes=3)
    other.close();f.close();return value

async def renewal_loss():
    f=Fixture('renewal-loss',lease=1.2);f.create([task('loss',30)])
    runner=asyncio.create_task(f.dag.arun('run'))
    await wait_for(lambda:f.factory.renewals>=1)
    f.factory.renewal_enabled=False
    await asyncio.sleep(1.5)
    f.factory.renewal_enabled=True
    with contextlib.suppress(asyncio.CancelledError): await asyncio.wait_for(runner,5)
    assert any(e['event']=='renewal_lost' for e in events(f.root))
    assert await resources_stopped(f.factory.resources)
    assert not f.store.list_artifacts('run')
    value=f.snapshot();value.update(all_process_trees_stopped=True,stale_result_published=False)
    f.close();return value

async def stale_publication():
    f=Fixture('stale-publication',lease=.6,heartbeat=False)
    f.create([task('stale')])
    epoch=f.store.acquire_scheduler_lease('run','old',.6)
    item,attempt=f.store.claim_ready_task('run','old:worker',.6)
    f.store.mark_attempt_running(attempt.attempt_id,attempt.lease_epoch)
    manifest=f.dag.artifact_store.stage(b'{"old":true}',run=f.dag.get_run('run'),task=item,attempt=attempt)
    manifest=f.store.save_staged_artifact(manifest,attempt.lease_epoch)
    request=VerificationRequest(kind='completion',run=f.dag.get_run('run'),task=item,attempt=attempt,
        input_snapshot_hash=attempt.input_snapshot_hash,candidate=manifest,candidate_content=b'{"old":true}',security_context=CTX)
    report=await CallableVerifier('old-check',lambda req:True).verify(request)
    await asyncio.sleep(.8)
    new_epoch=f.store.acquire_scheduler_lease('run','new',2)
    f.store.expire_attempts('run')
    f.store.claim_ready_task('run','new:worker',2)
    errors=[]
    for op in [lambda:f.store.renew_scheduler_lease('run','old',epoch,2),
               lambda:f.store.renew_attempt(attempt.attempt_id,attempt.lease_epoch,2),
               lambda:f.store.publish_artifact(manifest,report,attempt.lease_epoch)]:
        try: op()
        except DAGError as e: errors.append(e.code)
    assert len(errors)==3 and new_epoch>epoch
    published=[a for a in f.store.list_artifacts('run') if a.state=='published']
    assert not published
    value={'fencing_errors':errors,'old_epoch':epoch,'new_epoch':new_epoch,'published':len(published),'root':str(f.root)}
    f.close();return value

async def crash_child(root, docker=False):
    f=Fixture('crash',root=root,lease=1.2,review_delay=.05,docker=docker)
    f.create([task('finished',.1),task('interrupted',30,quick_retry=True)])
    await f.dag.arun('run')

async def crash_recovery(docker=False):
    root=ROOT/'runs'/('crash-'+uuid.uuid4().hex[:8]);root.mkdir(parents=True)
    process=await asyncio.create_subprocess_exec(sys.executable,__file__,'--crash-child',str(root),*(['--docker'] if docker else []),env=SAFE_ENV,
        stdout=asyncio.subprocess.PIPE,stderr=asyncio.subprocess.PIPE)
    store=SqliteTaskGraphStore(root/'state.db')
    await wait_for(lambda:store.get_task('run','finished') is not None and
        store.get_task('run','finished').state.status.value=='verified' and
        any(e['event']=='dispatch' and e['task']=='interrupted' for e in events(root)),timeout=15)
    artifacts=store.list_artifacts('run','finished');assert len(artifacts)==1
    before=artifacts[0].content_hash
    process.kill();await process.communicate()
    orphan=[json.loads(p.read_text()) for p in (root/'workers').glob('*/resource.json')
            if json.loads(p.read_text())['task']=='interrupted']
    orphan_alive=not await resources_stopped(orphan)
    reaped=await reap_orphans(root)
    assert orphan_alive and reaped==1
    await asyncio.sleep(1.5)
    recovered=Fixture('crash',root=root,lease=1.2,review_delay=.05,docker=docker)
    result=await recovered.dag.arun('run')
    assert result.success
    after=recovered.store.list_artifacts('run','finished')[0]
    assert before==after.content_hash and recovered.dag.artifact_store.check_integrity(after)
    assert recovered.dag.get_task('run','finished').state.attempt_count==1
    assert recovered.dag.get_task('run','interrupted').state.attempt_count==2
    dispatches=[e for e in events(root) if e['event']=='dispatch']
    assert len(dispatches)==3
    value=recovered.snapshot();value.update(scheduler_exit=process.returncode,
        orphan_survives_native_scheduler_crash=orphan_alive,adapter_reaped_orphans=reaped,
        preserved_artifact_hash=before,dispatch_count=len(dispatches))
    store.close();recovered.close();return value

async def run_case(name,operation):
    started=time.monotonic()
    try:
        detail=await operation()
        value={'case':name,'status':'pass','elapsed':round(time.monotonic()-started,3),'detail':detail}
    except BaseException as e:
        import traceback
        value={'case':name,'status':'fail','elapsed':round(time.monotonic()-started,3),'error':repr(e),'traceback':traceback.format_exc()}
    print(json.dumps(value),flush=True)
    with (ROOT/'results.jsonl').open('a') as f: f.write(json.dumps(value)+'\n')
    return value

async def main():
    parser=argparse.ArgumentParser();parser.add_argument('--case');parser.add_argument('--crash-child');parser.add_argument('--docker',action='store_true')
    args=parser.parse_args()
    if args.crash_child: return await crash_child(Path(args.crash_child),args.docker)
    cases={'long_run':long_run,'host_timeout_tree':lambda:timeout_tree(False),
        'container_timeout_tree':lambda:timeout_tree(True),'host_cancel_tree':lambda:cancel_tree(False),
        'container_cancel_tree':lambda:cancel_tree(True),'duplicate_dispatch_resume':duplicates,
        'renewal_loss':renewal_loss,'takeover_stale_publication':stale_publication,'crash_recovery':crash_recovery,'container_crash_recovery':lambda:crash_recovery(True)}
    selected={args.case:cases[args.case]} if args.case else cases
    results=[]
    for name,operation in selected.items(): results.append(await run_case(name,operation))
    return 1 if any(r["status"] != "pass" for r in results) else 0
if __name__=='__main__': sys.exit(asyncio.run(main()) or 0)
