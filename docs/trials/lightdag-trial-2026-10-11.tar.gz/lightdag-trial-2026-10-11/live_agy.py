"""One supervised native agy smoke through LightDAG; host cached auth stays in place."""
import asyncio, contextlib, json, os, signal, time, uuid
from pathlib import Path
from dataclasses import replace
from trial import ROOT, IMAGE, CTX, Fixture, TaskSpec, TaskOutcome, CallableVerifier, trace, command, cancellable_command

MODEL='gemini-3.7-flash-high'
PROMPT='Write a Python function chunked(items, size). items is a list and size is an integer. Return a list of new lists containing consecutive chunks of length size, with a shorter final chunk when needed. Empty input returns []. Raise ValueError when size is zero or negative. Do not mutate items. Return exactly a JSON object with one string field code containing the Python source, with no markdown fences. Do not call tools, read files, run commands, search, or use MCP. This is a pure code-generation task.'
CHECK='''import json\nfrom candidate import chunked\nitems=[1,2,3,4,5]\nassert chunked(items,2)==[[1,2],[3,4],[5]]\nassert items==[1,2,3,4,5]\nassert chunked([],2)==[]\nassert chunked([1,2],5)==[[1,2]]\nassert chunked([1,2],1)==[[1],[2]]\nfor size in [0,-1]:\n try: chunked([1],size)\n except ValueError: pass\n else: raise AssertionError('expected ValueError')\nresult=chunked(items,2)\nresult[0][0]=99\nassert items[0]==1\nprint(json.dumps({'checks':'passed'}))\n'''

class AgyWorker:
    def __init__(self,root): self.root=root;self.execution={}
    async def execute(self,context):
        argv=['/opt/homebrew/bin/agy','--sandbox','--disable-slash-commands','--model',MODEL,
              '--print-timeout','90s','--output-format','json','--print',PROMPT]
        # Existing user auth is resolved by agy itself. No credentials read/copied by this trial.
        env={'HOME':os.environ['HOME'],'PATH':os.environ['PATH'],'TMPDIR':str(self.root/'tmp')}
        (self.root/'tmp').mkdir(exist_ok=True)
        self.execution['argv']=argv
        start=time.monotonic()
        proc=await asyncio.create_subprocess_exec(*argv,cwd=self.root,env=env,start_new_session=True,
             stdin=asyncio.subprocess.DEVNULL,stdout=asyncio.subprocess.PIPE,stderr=asyncio.subprocess.PIPE)
        async def stopped():
            while not context.cancellation_token.cancelled: await asyncio.sleep(.1)
            raise asyncio.CancelledError()
        io=asyncio.create_task(proc.communicate());watch=asyncio.create_task(stopped())
        try:
            done,_=await asyncio.wait({io,watch},timeout=100,return_when=asyncio.FIRST_COMPLETED)
            if not done: raise TimeoutError('supervisor deadline')
            if watch in done: await watch
            out,err=await io
            (self.root/'response.json').write_bytes(out);(self.root/'stderr.txt').write_bytes(err)
            self.execution.update(exit_code=proc.returncode,elapsed=round(time.monotonic()-start,3))
            if proc.returncode: raise RuntimeError('agy nonzero exit')
            result=json.loads(out)
            if result.get('status')!='SUCCESS': raise ValueError('agy did not report SUCCESS')
            if result.get('num_turns')!=1: raise ValueError('expected one turn')
            session=result.get('conversation_id')
            if str(uuid.UUID(session))!=session: raise ValueError('invalid conversation id')
            payload=json.loads(result['response'])
            if set(payload)!={'code'} or not isinstance(payload['code'],str): raise ValueError('invalid code response')
            self.execution.update(status=result['status'],conversation_id=session,
                requested_model=MODEL,reported_model=result.get('model'),usage=result.get('usage'),
                model_attestation='CLI argument pinned; JSON result does not report selected model')
            return TaskOutcome.candidate(payload['code'])
        finally:
            watch.cancel()
            with contextlib.suppress(asyncio.CancelledError): await watch
            if proc.returncode is None:
                with contextlib.suppress(ProcessLookupError): os.killpg(proc.pid,signal.SIGTERM)
                try: await asyncio.wait_for(proc.wait(),2)
                except asyncio.TimeoutError:
                    with contextlib.suppress(ProcessLookupError): os.killpg(proc.pid,signal.SIGKILL)
                    await proc.wait()
            io.cancel()
            with contextlib.suppress(asyncio.CancelledError): await io

async def main():
    f=Fixture('live-agy',lease=4,concurrency=1)
    f.config=replace(f.config,max_attempts_per_task=1)
    f.dag.config=f.config;f.factory.config=f.config
    worker=AgyWorker(f.root)
    f.factory.register('external-cli',worker)
    verification={}
    async def verify(request):
        check=f.root/'verification';check.mkdir(exist_ok=True)
        (check/'candidate.py').write_bytes(request.candidate_content)
        (check/'check.py').write_text(CHECK)
        name='rapid-ship-lightdag-live-'+uuid.uuid4().hex[:10]
        args=['docker','run','--rm','--name',name,'--label','rapid-ship.trial=lightdag',
            '--network','none','--read-only','--cap-drop','ALL','--security-opt','no-new-privileges',
            '--pids-limit','32','--memory','128m','--cpus','0.5','--user',f'{os.getuid()}:{os.getgid()}',
            '--tmpfs','/tmp:rw,nosuid,nodev,size=8m','--mount',f'type=bind,src={check},dst=/check,readonly',
            '--workdir','/check',IMAGE,'python','-B','check.py']
        try:
            rc,out,err=await asyncio.wait_for(cancellable_command(args,lambda:f.dag.get_run('run').status.value!='running',timeout=120),125)
            verification.update(exit_code=rc,stdout=out,stderr=err,image=IMAGE)
            return rc==0 and json.loads(out)=={'checks':'passed'}
        finally: await command('docker','rm','--force',name)
    f.dag.verifiers['independent']=CallableVerifier('independent',verify,timeout=140)
    f.create([TaskSpec(task_id='chunked',goal='Generate chunked function',acceptance_contract={'function':'chunked'},
        worker_key='external-cli',verifier_key='independent',metadata={'model':MODEL})])
    started=time.monotonic()
    result=await f.dag.arun('run')
    record={'kind':'live-coding-model-smoke','elapsed':round(time.monotonic()-started,3),
            'lightdag':f.snapshot(),'worker':worker.execution,'verification':verification,
            'limitations':['native host cached authentication; no Docker-auth trial',
              'supervised no-tool prompt, not unattended tool permissions or coding harness conformance',
              'selected model not present in JSON output; only explicit argv and status validated']}
    path=ROOT/'live-agy-result.json';path.write_text(json.dumps(record,indent=2))
    print(json.dumps(record),flush=True)
    f.close()
    if not result.success: raise SystemExit(1)
asyncio.run(main())
