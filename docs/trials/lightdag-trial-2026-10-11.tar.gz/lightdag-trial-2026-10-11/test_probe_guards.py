"""Protect the trial itself against false green cleanup checks."""
import asyncio, json
import pytest
import trial

@pytest.mark.parametrize('state',[{'Running':True,'Status':'running'}, {'Running':False,'Status':'created'}, {'Running':False,'Status':'exited'}])
def test_existing_container_is_not_removed(monkeypatch,state):
 async def response(*args,**kwargs): return 0,json.dumps(state),''
 monkeypatch.setattr(trial,'command',response)
 assert asyncio.run(trial.resources_stopped([{'container':'test'}])) is False

@pytest.mark.parametrize('message',['Cannot connect to the Docker daemon','permission denied','context deadline exceeded','Error response from daemon: No such image: test'])
def test_inspection_failure_is_not_cleanup_success(monkeypatch,message):
 async def response(*args,**kwargs): return 1,'',message
 monkeypatch.setattr(trial,'command',response)
 with pytest.raises(RuntimeError,match='Docker inspection failed'):
  asyncio.run(trial.resources_stopped([{'container':'test'}]))

def test_explicit_container_absence_is_success(monkeypatch):
 async def response(*args,**kwargs): return 1,'','Error response from daemon: No such container: test\n'
 monkeypatch.setattr(trial,'command',response)
 assert asyncio.run(trial.resources_stopped([{'container':'test'}])) is True

def test_edge_case_runner_propagates_failure(monkeypatch):
 import edge_cases
 async def failed(*args,**kwargs): return {'status':'fail'}
 monkeypatch.setattr(edge_cases,'run_case',failed)
 assert asyncio.run(edge_cases.main())==1

@pytest.mark.parametrize('payload,code,expected',[
 ('{"checks":"passed"}',0,0),('{"checks":"failed"}',0,1),
 ('{"checks":"passed"}',1,1),('not JSON',0,1)])
def test_standalone_verifier_exit_matches_result(tmp_path,payload,code,expected):
 import os,shutil,subprocess,sys
 source=trial.ROOT/'verify_live_candidate.py'
 shutil.copy2(source,tmp_path/source.name)
 (tmp_path/'live-agy-initial-result.json').write_text('{"lightdag":{"root":"missing"}}')
 (tmp_path/'live-candidate.py').write_text('')
 (tmp_path/'live-check.py').write_text('')
 fake=tmp_path/'docker'
 fake.write_text('#!'+sys.executable+'\nimport sys\nif sys.argv[1]=="run":\n print('+repr(payload)+')\n raise SystemExit('+str(code)+')\n')
 fake.chmod(0o755)
 env={'PATH':str(tmp_path)+':/usr/bin:/bin','HOME':str(tmp_path)}
 result=subprocess.run([sys.executable,str(tmp_path/source.name)],env=env,capture_output=True,text=True,timeout=10)
 assert result.returncode==expected,result.stderr
 summary=json.loads((tmp_path/'live-candidate-verification.json').read_text())
 assert summary['status']==('pass' if expected==0 else 'fail')
